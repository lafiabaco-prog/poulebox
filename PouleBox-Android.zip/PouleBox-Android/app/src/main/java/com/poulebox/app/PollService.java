package com.poulebox.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.job.JobInfo;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobService;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

/** Vérifie périodiquement Firebase et affiche une notification Android. */
public class PollService extends JobService {

    static final String PREFS = "poll";
    static final int JOB_ID = 4711;
    static final String CHANNEL = "poulailler";

    static void schedule(Context c) {
        JobScheduler js = (JobScheduler) c.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        if (js == null) return;
        JobInfo.Builder b = new JobInfo.Builder(JOB_ID, new ComponentName(c, PollService.class))
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .setPersisted(true)
                .setPeriodic(15 * 60 * 1000L);
        try {
            js.schedule(b.build());
        } catch (Exception ignored) {
        }
    }

    static void cancel(Context c) {
        JobScheduler js = (JobScheduler) c.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        if (js != null) js.cancel(JOB_ID);
    }

    static void notifyUser(Context c, String title, String text) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Mon Poulailler", NotificationManager.IMPORTANCE_DEFAULT));
        }
        Intent i = new Intent(c, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        int fl = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        PendingIntent pi = PendingIntent.getActivity(c, 0, i, fl);
        Notification.Builder nb = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(c, CHANNEL) : new Notification.Builder(c);
        nb.setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setContentIntent(pi)
                .setAutoCancel(true);
        nm.notify((int) (System.currentTimeMillis() % 100000), nb.build());
    }

    @Override
    public boolean onStartJob(final JobParameters params) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    check(PollService.this);
                } catch (Exception ignored) {
                }
                jobFinished(params, false);
            }
        }).start();
        return true;
    }

    @Override
    public boolean onStopJob(JobParameters params) {
        return true;
    }

    static String http(String method, String url, String bearer, String body) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setRequestMethod(method);
        c.setConnectTimeout(12000);
        c.setReadTimeout(12000);
        if (bearer != null) c.setRequestProperty("Authorization", "Bearer " + bearer);
        if (body != null) {
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json");
            OutputStream o = c.getOutputStream();
            o.write(body.getBytes(StandardCharsets.UTF_8));
            o.close();
        }
        int code = c.getResponseCode();
        if (code < 200 || code >= 300) return null;
        InputStream in = c.getInputStream();
        BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String l;
        while ((l = r.readLine()) != null) sb.append(l);
        r.close();
        return sb.toString();
    }

    static String sv(JSONObject f, String k) {
        JSONObject o = f == null ? null : f.optJSONObject(k);
        if (o == null) return "";
        if (o.has("stringValue")) return o.optString("stringValue");
        if (o.has("integerValue")) return o.optString("integerValue");
        if (o.has("doubleValue")) return o.optString("doubleValue");
        return "";
    }

    static void check(Context c) throws Exception {
        SharedPreferences sp = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String cfgS = sp.getString("cfg", null);
        if (cfgS == null) return;
        JSONObject cfg = new JSONObject(cfgS);
        String proj = cfg.optString("proj"), key = cfg.optString("key");
        String base = "https://firestore.googleapis.com/v1/projects/" + URLEncoder.encode(proj, "UTF-8")
                + "/databases/(default)/documents";
        SharedPreferences.Editor ed = sp.edit();
        if ("worker".equals(cfg.optString("role"))) {
            String s = http("GET", base + "/pub/state?key=" + URLEncoder.encode(key, "UTF-8"), null, null);
            if (s != null) {
                JSONObject f = new JSONObject(s).optJSONObject("fields");
                String ts = sv(f, "statTs");
                String known = sp.getString("sTs", "");
                if (ts.length() > 0 && known.length() > 0 && !ts.equals(known)) {
                    String st = sv(f, "statut");
                    String lbl = "pret".equals(st) ? "Prêts à la vente" : ("bientot".equals(st) ? "Bientôt prêts" : "En croissance");
                    String t = lbl + " · " + ("1".equals(sv(f, "cmd")) ? "commandes ouvertes" : "commandes fermées");
                    String m = sv(f, "msg");
                    if (m.length() > 0) t += " · " + m;
                    notifyUser(c, "Statut des poulets", t);
                }
                if (ts.length() > 0) ed.putString("sTs", ts);
            }
            String tok = cfg.optString("tok");
            if (tok.length() > 0) {
                String g = http("GET", base + "/g/" + URLEncoder.encode(tok, "UTF-8") + "?key=" + URLEncoder.encode(key, "UTF-8"), null, null);
                if (g != null) {
                    String dec = sv(new JSONObject(g).optJSONObject("fields"), "dec");
                    String old = sp.getString("dec", null);
                    if (old != null && !old.equals(dec) && dec.length() > 2) {
                        notifyUser(c, "Vos saisies", "Le propriétaire a traité une de vos saisies (validée ou rejetée).");
                    }
                    ed.putString("dec", dec);
                }
            }
        } else if ("owner".equals(cfg.optString("role"))) {
            String body = new JSONObject().put("email", cfg.optString("mail")).put("password", cfg.optString("pass"))
                    .put("returnSecureToken", true).toString();
            String a = http("POST", "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=" + URLEncoder.encode(key, "UTF-8"), null, body);
            if (a != null) {
                String tk = new JSONObject(a).optString("idToken");
                String l = http("GET", base + "/reports?pageSize=50", tk, null);
                int n = 0;
                if (l != null) {
                    JSONArray arr = new JSONObject(l).optJSONArray("documents");
                    n = arr == null ? 0 : arr.length();
                }
                int last = sp.getInt("nrep", 0);
                if (n > 0 && n != last) {
                    notifyUser(c, "Saisies à valider", n + " saisie" + (n > 1 ? "s" : "") + " des gérants à valider");
                }
                ed.putInt("nrep", n);
            }
        }
        ed.apply();
    }
}
