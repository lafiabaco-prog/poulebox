package com.poulebox.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        if (c.getSharedPreferences(PollService.PREFS, Context.MODE_PRIVATE).getString("cfg", null) != null) {
            PollService.schedule(c);
        }
    }
}
