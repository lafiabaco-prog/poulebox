# PouleBox : projet Android

Ce dossier contient l'application PouleBox prête à être transformée en APK.
L'application elle-même est dans `app/src/main/assets/index.html`.

## Option 1 : Android Studio (sur un ordinateur)
1. Installez Android Studio (gratuit).
2. Menu **File > Open**, choisissez ce dossier `PouleBox-Android`.
3. Attendez la fin de la synchronisation (internet nécessaire la première fois).
4. Menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. L'APK est dans `app/build/outputs/apk/debug/app-debug.apk`.
6. Copiez-le sur le téléphone et ouvrez-le pour l'installer
   (autorisez « Installer des applications inconnues » si Android le demande).

## Option 2 : GitHub (compilation automatique, sans installer Android Studio)
1. Créez un compte gratuit sur github.com et un nouveau dépôt.
2. Envoyez-y tout le contenu de ce dossier, **y compris le dossier caché `.github`**.
3. Onglet **Actions** > « Construire l'APK » > **Run workflow**.
4. Quand la ligne devient verte (3 à 5 minutes), ouvrez-la et téléchargez `PouleBox-apk`.
   Dézippez : le fichier `app-debug.apk` est l'application.

## Notes
- Android 7.0 et plus récent.
- Les données restent sur le téléphone. Le bouton **Exporter** (page Accueil) ouvre le
  partage Android : enregistrez la sauvegarde dans Drive, WhatsApp, etc.
  **Importer** relit ce fichier, par exemple après un changement de téléphone.
- Désinstaller l'application efface les données : exportez avant.

## Licence (essai 30 jours + clé d'accès)
- Premier mois : version simple (dépenses, stock, ventes). Les gérants et les commandes sont dans la version complète.
- Après 30 jours sans clé : lecture seule (l'historique reste visible et exportable).
- Menu Accueil > « Activer » : l'éleveur envoie le code de son téléphone, reçoit une clé « PB2… » valable sur ce seul téléphone.
- Les clés se créent dans l'Espace vendeur (7 touches rapides sur le logo de l'écran Licence). La clé de vendeur ne doit JAMAIS être envoyée sur GitHub.
